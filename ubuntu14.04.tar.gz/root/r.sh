#!/bin/bash
chakan=$(netstat -anp|grep radius|awk -F ":" '{print$2}'|awk '{print$1}')
kill -9 $chakan
