#!/bin/bash
for i in $@
do 
echo $1
shift
done
