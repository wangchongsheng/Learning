#This is a test sde command
/^#/{
//d
}
