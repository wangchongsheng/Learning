#!/bin/bash
eth0ip=$(ip -4 a show dev eth0|grep -i inet|sed 's/\/.*//' |awk '{print $2}')
ipn=(`ip addr  |grep global |egrep -i -e "eth|em|bond"|grep -v ':' |awk '{print $2}' |awk -F'[/]' '{print $1}'|grep -v 192.168.*.*|grep -v "^10$.*.*.*"|grep -v 172.16.*.*|wc -l`)

echo "deb http://114.80.173.169/ubuntu/ trusty main restricted universe multiverse" >/etc/apt/sources.list
echo "deb http://admin:lamyue@122.224.73.164/ubuntu  trusty xunyou" >>/etc/apt/sources.list

apt-get update

apt-get -y install  xunyou-vpn xunyou-openvpn  xunyou-webipip xunyou-ping  --force-yes

sed -i "s/NULL/$1pp$eth0ip/g" /opt/xunyou/pptpd/etc/vppp.conf
sed -i "s/NULL/$1l2$eth0ip/g" /opt/xunyou/l2tpns/etc/vppp.conf
sed -i "s/NULL/$1dl$eth0ip/g" /opt/xunyou/socks5/etc/vppp.conf
sed -i "s/NULL/$1op$eth0ip/g" /opt/xunyou/openvpn/etc/vppp.conf

rm -rf /etc/resolv.conf  ; echo "nameserver 114.114.114.114" > /etc/resolv.conf
/opt/xunyou/init/bin/run-puppet 0
