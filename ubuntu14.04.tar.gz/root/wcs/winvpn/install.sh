#!/bin/sh
echo "deb http://182.132.165.84:20000/ubuntu-old maverick main multiverse  restricted  universe" >/etc/apt/sources.list
echo "deb http://admin:lamyue@122.224.73.164/deb  maverick main" >>/etc/apt/sources.list
echo "nameserver 61.139.2.69" >/etc/resolv.conf
sleep 1
mkdir -p /root/.ssh
sleep 1
groupadd nobody
grep 'db.lamyu.com' /etc/hosts || echo "59.151.39.237 db.lamyu.com" >>/etc/hosts
grep 'spdcollect' /etc/hosts || echo "59.151.39.242   spdcollect.xunyou.com" >>/etc/hosts
echo "* hard nofile 65535" >>/etc/security/limits.conf 
echo "* soft nofile 65535" >>/etc/security/limits.conf
echo "export HISTTIMEFORMAT='%F %T '" >>/etc/profile

sleep 1
cp -f inrc.local /etc/rc.local
cp ./syslog.conf /etc/syslog.conf
sleep 1
/etc/init.d/rsyslog restart

sleep 1
echo "ulimit -c unlimited" >>/etc/profile
echo "ulimit -n 65535" >>/etc/profile
sed -i '/^/s/^/#/' /etc/rsyslog.d/*
echo 1 >/proc/sys/net/ipv4/tcp_thin_dupack 
echo 1 >/proc/sys/net/ipv4/tcp_thin_linear_timeouts 
echo 1 >/proc/sys/net/ipv4/tcp_low_latency 

/etc/init.d/apparmor reload
cd
