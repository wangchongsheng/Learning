#!/bin/sh


#ctcgw="59.32.180.129"
#cncgw="221.5.58.129"

while read LINE
                do
                        /bin/ping -c 100 -i 0.1 $LINE >./test/$LINE &
                done < ./ctclist
outdate()
{
        while read LINE
         do
                echo $LINE  `cat ./test/$LINE |grep "min/avg/max/mdev"` `cat ./test/$LINE |grep "packet"`  >>./test/out
         done < ./ctclist
}
sleep 20
out()
{
	awk '{print $1,$5,$12}' ./test/out |awk  -F '[ /]' '{print $2"/"$4"/"$3}' >./test/outping
	awk -F 'received,' '{print $2}' ./test/out|awk '{print $1}' >./test/outloss
}
outdate 
sleep 1
out
paste -d/ ./test/outping ./test/outloss >./test/end
cat ./test/end
rm ./test/*
