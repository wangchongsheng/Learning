#!/bin/sh
usage()
{
echo "usage:`basename $0` add|del 127.0.0.1"
}
OPT=$1
gwip=$2
if [ $# -ne 2 ]
        then 
                usage
                exit 1
fi
case $OPT in
add|Add) 
	while read LINE
	do
    		route add -host $LINE/32 gw $gwip
	done < ./gwlist

;;
del|Del) echo 
	while read LINE
	do
    		route del -host $LINE/32 gw $gwip
	done < ./gwlist
;;
*)usage
;;
esac

