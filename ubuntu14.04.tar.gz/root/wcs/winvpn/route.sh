#!/bin/sh
usage()
{
echo "usage:`basename $0` add|del 127.0.0.1 ctclist|cnclist"
}
OPT=$1
LST=$3
GIP=$2
if [ $# -ne 3 ]
        then 
                usage
       		 exit 1
fi
case $OPT in
add|Add) 
        while read LINE
        do
                route add -net $LINE gw $GIP
        done < $LST

;;
del|Del) echo 
        while read LINE
        do
                route del -net $LINE gw $GIP
        done < $LST
;;
*)usage
;;
esac
