#!/bin/bash
killall mrtg
mkdir -p /var/www/mrtg
mkdir -p /etc/mrtg/
mkdir -p /opt/mrtg

city=(CTC_BeiJing CTC_ShangHai CTC_GuangZhou CTC_ChengDu CTC_WuHan CTC_NanJing WOW
CNC_BeiJing CNC_ShangHai CNC_GuangZhou CNC_ChengDu CNC_WuHan CNC_NanJing CTWG)
ip=(220.181.22.228 61.152.87.194 202.97.26.54 118.123.1.1 61.136.171.1 202.102.33.1 115.238.35.5
 61.49.39.1 210.22.67.1 221.4.0.29 221.10.251.1 218.104.110.1 58.240.48.43 211.144.149.1)

# ----------------------------------------------
ping_bin="/usr/bin/mrtg-ping-probe"
ping_mrtg="/etc/mrtg/mrtg.cfg-ping"
echo 'WorkDir:/var/www/mrtg
RunAsDaemon:Yes
Refresh:600
Interval:5
NoMib2:Yes
Language: gb
LoadMIBs:/usr/share/snmp/mibs/UCD-SNMP-MIB.txt
'>$ping_mrtg

# ----------------------------------------------
for ((i=0,j=0;i<${#ip[@]},j<${#city[@]};i++,j++));do
echo "
Title[${ip[i]}.ping]: ${city[$j]} ${ip[$i]} ping
PageTop[${ip[i]}.ping]: <H1>${city[$j]} ${ip[$i]} ping</H1>
Target[${ip[i]}.ping]: {$ping_bin -k 100 -o '-i 0.1' -p avg/max ${ip[$i]}}
MaxBytes[${ip[i]}.ping]: 1000
Options[${ip[i]}.ping]: gauge,growright,noinfo
YLegend[${ip[i]}.ping]: round trip time 
ShortLegend[${ip[i]}.ping]: ms
LegendI[${ip[i]}.ping]: &nbsp;Avg:
LegendO[${ip[i]}.ping]: &nbsp;Max:
Directory[${ip[i]}.ping]: ping

Title[${ip[i]}.loss]: ${city[$j]} ${ip[$i]} loss
PageTop[${ip[i]}.loss]: <H1>${city[$j]} ${ip[$i]} loss</H1>
Target[${ip[i]}.loss]: {$ping_bin -k 100 -o '-i 0.1' -p loss/loss ${ip[$i]}|tee /opt/mrtg/${ip[$i]}}
MaxBytes[${ip[i]}.loss]: 1000
Options[${ip[i]}.loss]: gauge,growright,noinfo
YLegend[${ip[i]}.loss]: % Packet Loss
ShortLegend[${ip[i]}.loss]: %
Background[${ip[i]}.loss]: #cce8cf
LegendI[${ip[i]}.loss]: &nbsp;% loss:
LegendO[${ip[i]}.loss]: &nbsp;% loss:
Directory[${ip[i]}.loss]: ping
">>$ping_mrtg
done
sed -i 's/{\(.*\)}/`\1`/g' $ping_mrtg
env LANG=C /usr/bin/mrtg $ping_mrtg
indexmaker /etc/mrtg/mrtg.cfg-ping >/var/www/mrtg/index.html
