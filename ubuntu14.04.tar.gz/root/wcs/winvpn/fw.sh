#!/bin/bash

iptables -P INPUT ACCEPT
iptables -P OUTPUT ACCEPT
iptables -P FORWARD ACCEPT

iptables -F
iptables -F -t nat
iptables -t raw -A PREROUTING -s 172.16.0.0/16 -d  172.16.0.0/16 -j DROP
iptables -t raw -A PREROUTING -s 10.10.0.0/16 -d  10.10.0.0/16 -j DROP
iptables -t nat -A POSTROUTING -s 172.16.0.0/16 ! -d  172.16.0.0/16 -j MASQUERADE
iptables -t nat -A POSTROUTING -s 172.18.0.0/16 ! -d  172.18.0.0/16 -j MASQUERADE
iptables -t nat -A POSTROUTING -s 10.10.0.0/16 ! -d  10.10.0.0/16 -j MASQUERADE

iptables -A FORWARD -p icmp --icmp-type 8 -j ACCEPT
iptables -A FORWARD -p icmp --icmp-type 0 -j ACCEPT
iptables -A FORWARD -p icmp -j DROP
iptables -A INPUT -p tcp -m state --state NEW --tcp-flags FIN,SYN,RST,ACK ACK -m limit --limit 100/s --limit-burst 150 -j ACCEPT
iptables -A INPUT -p tcp -m state --state NEW --tcp-flags FIN,SYN,RST,ACK SYN -m limit --limit 100/s --limit-burst 150 -j ACCEPT
iptables -A INPUT -p tcp -m state --state NEW --tcp-flags FIN,SYN,RST,ACK SYN -j DROP
iptables -A INPUT -p tcp -m state --state NEW --tcp-flags FIN,SYN,RST,ACK ACK -j DROP

iptables -A OUTPUT -p icmp --icmp-type 0 -j DROP
iptables -I OUTPUT -p icmp -d 119.6.126.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 119.6.97.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 122.224.73.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 124.160.70.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 125.71.215.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 182.132.165.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 221.237.152.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 59.151.39.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 59.151.27.0/24  -j ACCEPT
iptables -I OUTPUT -p icmp -d 222.66.12.166   -j ACCEPT
iptables -I OUTPUT -p icmp -d 180.153.108.14    -j ACCEPT
iptables -I OUTPUT -p icmp -d 222.73.4.214   -j ACCEPT
iptables -I OUTPUT -p icmp -d 61.38.252.215   -j ACCEPT
