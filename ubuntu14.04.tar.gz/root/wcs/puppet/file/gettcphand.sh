#!/bin/bash
eth0ip=$(ip a show dev eth0|grep "\<inet\>"|awk '{print $2}'|sed 's/\/.*//')
eth1ip=$(ip a show dev eth1|grep "\<inet\>"|awk '{print $2}'|sed 's/\/.*//')

sh=$(echo $eth0ip $eth1ip|sed 's/ / or src host /g'|sed 's/^/(src host /'|sed s'/$/)/')
dh=$(echo $eth0ip $eth1ip|sed 's/ / or dst host /g'|sed 's/^/(dst host /'|sed s'/$/)/')


filter="($sh and tcp[13]&18==2 and ! dst port 80 and ! net 172.16.0.0/16 ) or ($dh and tcp[13]&18==18 and ! src port 80 and ! net 172.16.0.0/16)"

mkdir /tmp/tcphand  2>/dev/null
[ -d /tmp/tcphand ]&&nice -n 19 tcpdump -n -tt -G 3600 -w /tmp/tcphand/data."%w"."%H" -i any  "$filter"
